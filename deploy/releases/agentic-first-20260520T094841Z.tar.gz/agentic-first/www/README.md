# Agentic First static site

This is the top-level Agentic First tools directory for:

```text
https://agentic-first.co/
```

It intentionally does not contain the product standards, schemas,
validators, examples, skills, MCP service, or product static pages. Those
live in the `pitch-mcp` repo and are exposed under:

```text
https://agentic-first.co/companies/
https://agentic-first.co/directory/
```

`/companies/` is the company/person profile directory: a way for companies
and people to store public information online so agents can find, verify, and
use the right facts. `/directory/` is the Agentics Tool Directory: the catalog
of Agentic First tools, standards, runtimes, protocols, and operating patterns.

The favicon is `favicon.svg` at the web root so browsers can load it from
`https://agentic-first.co/favicon.svg`.

`agent-first.co` is the memorable alternate domain and should redirect
to `agentic-first.co`.
